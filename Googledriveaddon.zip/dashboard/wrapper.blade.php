{{--
    AutomaticGoogleDriveBackups – Dashboard Wrapper
    Injected into the Pterodactyl server dashboard layout.
    Adds a "Google Drive" section visible on all server pages.
--}}

@php
    $userId    = Auth::id();
    $token     = \DB::table('gdrive_tokens')->where('user_id', $userId)->first();
    $connected = !is_null($token);

    // Allow-user setting from admin config
    $allowConnect = \DB::table('blueprint_extension_settings')
        ->where('extension', '{identifier}')
        ->where('key', 'allow_user_oauth')
        ->value('value') ?? '1';

    // Per-server backup settings (if a server UUID exists in the URL)
    $serverUuid = request()->route('server') ?? null;
    $backupSettings = null;
    $backupLogs = collect();

    if ($serverUuid && $connected) {
        $backupSettings = \DB::table('gdrive_backup_settings')
            ->where('user_id', $userId)
            ->where('server_id', $serverUuid)
            ->first();

        $backupLogs = \DB::table('gdrive_backup_logs')
            ->where('user_id', $userId)
            ->where('server_id', $serverUuid)
            ->orderByDesc('created_at')
            ->limit(5)
            ->get();
    }
@endphp

{{-- ======================================================
     Styles – injected outside React bundle
     ====================================================== --}}
<style>
    /* ----- Floating Google Drive FAB Trigger ----- */
    #gdrive-fab {
        position: fixed;
        bottom: 28px;
        right: 28px;
        z-index: 9999;
        width: 54px;
        height: 54px;
        border-radius: 50%;
        background: linear-gradient(135deg, #4285f4, #1a73e8);
        color: #fff;
        border: none;
        cursor: pointer;
        box-shadow: 0 6px 20px rgba(66,133,244,.45);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        transition: transform .2s, box-shadow .2s;
    }
    #gdrive-fab:hover {
        transform: scale(1.1);
        box-shadow: 0 10px 28px rgba(66,133,244,.55);
    }
    #gdrive-fab .gdrive-badge {
        position: absolute;
        top: -4px;
        right: -4px;
        width: 14px;
        height: 14px;
        background: #34d399;
        border-radius: 50%;
        border: 2px solid #0f172a;
    }

    /* ----- Slide-over Panel ----- */
    #gdrive-panel {
        position: fixed;
        top: 0;
        right: -420px;
        width: 420px;
        height: 100vh;
        z-index: 10000;
        background: #0f172a;
        border-left: 1px solid #1e293b;
        box-shadow: -8px 0 40px rgba(0,0,0,.5);
        display: flex;
        flex-direction: column;
        transition: right .3s cubic-bezier(.4,0,.2,1);
        font-family: 'Inter', system-ui, sans-serif;
    }
    #gdrive-panel.open { right: 0; }

    /* Overlay */
    #gdrive-overlay {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 9998;
        background: rgba(0,0,0,.45);
        backdrop-filter: blur(2px);
    }
    #gdrive-overlay.visible { display: block; }

    /* Panel header */
    .gd-header {
        padding: 22px 24px 18px;
        border-bottom: 1px solid #1e293b;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
    }
    .gd-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .gd-header-icon {
        width: 36px;
        height: 36px;
        background: linear-gradient(135deg,#4285f4,#1a73e8);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        color: #fff;
    }
    .gd-header h2 {
        margin: 0;
        font-size: 1rem;
        font-weight: 700;
        color: #f1f5f9;
    }
    .gd-header p {
        margin: 2px 0 0;
        font-size: 0.75rem;
        color: #64748b;
    }
    .gd-close {
        background: none;
        border: none;
        color: #475569;
        font-size: 18px;
        cursor: pointer;
        padding: 6px;
        border-radius: 6px;
        transition: color .15s, background .15s;
    }
    .gd-close:hover { color: #f1f5f9; background: #1e293b; }

    /* Tabs */
    .gd-tabs {
        display: flex;
        border-bottom: 1px solid #1e293b;
        flex-shrink: 0;
    }
    .gd-tab {
        flex: 1;
        padding: 12px;
        background: none;
        border: none;
        color: #64748b;
        font-size: 0.8rem;
        font-weight: 600;
        cursor: pointer;
        border-bottom: 2px solid transparent;
        transition: all .15s;
        text-transform: uppercase;
        letter-spacing: .04em;
    }
    .gd-tab.active {
        color: #4285f4;
        border-bottom-color: #4285f4;
    }
    .gd-tab:hover { color: #94a3b8; }

    /* Panel body */
    .gd-body {
        flex: 1;
        overflow-y: auto;
        padding: 20px 24px;
        scrollbar-width: thin;
        scrollbar-color: #1e293b transparent;
    }

    /* Cards */
    .gd-card {
        background: #131929;
        border: 1px solid #1e293b;
        border-radius: 10px;
        padding: 18px 20px;
        margin-bottom: 14px;
    }
    .gd-card h3 {
        margin: 0 0 14px;
        font-size: .85rem;
        font-weight: 700;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: .05em;
    }

    /* Status badge */
    .gd-status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: .8rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 20px;
    }
    .gd-status.connected {
        background: rgba(52,211,153,.12);
        color: #34d399;
        border: 1px solid rgba(52,211,153,.25);
    }
    .gd-status.disconnected {
        background: rgba(248,113,113,.1);
        color: #f87171;
        border: 1px solid rgba(248,113,113,.2);
    }

    /* Buttons */
    .gd-btn {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 9px 18px;
        border-radius: 8px;
        font-size: .85rem;
        font-weight: 600;
        cursor: pointer;
        border: none;
        text-decoration: none;
        transition: all .2s;
        width: 100%;
        justify-content: center;
    }
    .gd-btn-google {
        background: #fff;
        color: #1a1a2e;
        box-shadow: 0 2px 8px rgba(0,0,0,.2);
    }
    .gd-btn-google:hover {
        background: #f1f5f9;
        transform: translateY(-1px);
    }
    .gd-btn-primary {
        background: linear-gradient(135deg,#4285f4,#1a73e8);
        color: #fff;
        box-shadow: 0 3px 10px rgba(66,133,244,.3);
    }
    .gd-btn-primary:hover {
        background: linear-gradient(135deg,#5a95f5,#2b7de9);
        transform: translateY(-1px);
    }
    .gd-btn-danger {
        background: rgba(239,68,68,.1);
        color: #f87171;
        border: 1px solid rgba(239,68,68,.25);
    }
    .gd-btn-danger:hover {
        background: rgba(239,68,68,.2);
    }
    .gd-btn-secondary {
        background: #1e293b;
        color: #94a3b8;
        border: 1px solid #2d3450;
    }
    .gd-btn-secondary:hover {
        background: #263348;
        color: #e2e8f0;
    }
    .gd-btn + .gd-btn { margin-top: 8px; }

    /* Form elements */
    .gd-form-group {
        margin-bottom: 14px;
    }
    .gd-form-group label {
        display: block;
        font-size: .75rem;
        font-weight: 600;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: .04em;
        margin-bottom: 6px;
    }
    .gd-form-group input[type=text],
    .gd-form-group select {
        width: 100%;
        box-sizing: border-box;
        background: #0f172a;
        border: 1px solid #1e293b;
        border-radius: 7px;
        color: #e2e8f0;
        padding: 9px 12px;
        font-size: .875rem;
        outline: none;
        transition: border-color .2s, box-shadow .2s;
    }
    .gd-form-group input:focus,
    .gd-form-group select:focus {
        border-color: #4285f4;
        box-shadow: 0 0 0 3px rgba(66,133,244,.15);
    }

    /* Toggle */
    .gd-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
    }
    .gd-toggle-label { font-size: .875rem; color: #e2e8f0; }
    .gd-switch { position: relative; display: inline-block; width: 42px; height: 24px; flex-shrink:0; }
    .gd-switch input { opacity:0; width:0; height:0; }
    .gd-slider {
        position:absolute; cursor:pointer; inset:0;
        background:#1e293b; border-radius:34px; transition:.25s;
    }
    .gd-slider:before {
        position:absolute; content:""; height:16px; width:16px;
        left:4px; bottom:4px; background:#fff; border-radius:50%; transition:.25s;
    }
    input:checked + .gd-slider { background:#4285f4; }
    input:checked + .gd-slider:before { transform:translateX(18px); }

    /* Log items */
    .gd-log-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 0;
        border-bottom: 1px solid #1a2035;
        font-size: .8rem;
    }
    .gd-log-item:last-child { border-bottom: none; }
    .gd-log-icon { font-size: 14px; flex-shrink: 0; }
    .gd-log-info { flex: 1; }
    .gd-log-name { color: #e2e8f0; font-weight: 500; }
    .gd-log-date { color: #475569; margin-top: 2px; }
    .gd-log-size { color: #64748b; font-size: .75rem; }

    /* Alert flash */
    .gd-flash {
        border-radius: 8px;
        padding: 10px 14px;
        font-size: .82rem;
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 14px;
    }
    .gd-flash-success {
        background: rgba(52,211,153,.1);
        border: 1px solid rgba(52,211,153,.25);
        color: #34d399;
    }
    .gd-flash-error {
        background: rgba(248,113,113,.1);
        border: 1px solid rgba(248,113,113,.2);
        color: #f87171;
    }

    /* Tab panes */
    .gd-pane { display: none; }
    .gd-pane.active { display: block; }

    /* Empty state */
    .gd-empty {
        text-align: center;
        padding: 30px 0;
        color: #475569;
        font-size: .85rem;
    }
    .gd-empty span { font-size: 2rem; display: block; margin-bottom: 8px; }

    @media (max-width: 480px) {
        #gdrive-panel { width: 100vw; right: -100vw; }
    }
</style>

{{-- ============ FAB Button ============ --}}
<button id="gdrive-fab" onclick="gdriveOpenPanel()" title="Google Drive Backups">
    🟦
    @if($connected)
    <span class="gdrive-badge"></span>
    @endif
</button>

{{-- ============ Overlay ============ --}}
<div id="gdrive-overlay" onclick="gdriveClosePanel()"></div>

{{-- ============ Slide-over Panel ============ --}}
<div id="gdrive-panel">

    {{-- Header --}}
    <div class="gd-header">
        <div class="gd-header-left">
            <div class="gd-header-icon">🟦</div>
            <div>
                <h2>Google Drive Backups</h2>
                <p>Automatic daily server backups</p>
            </div>
        </div>
        <button class="gd-close" onclick="gdriveClosePanel()">✕</button>
    </div>

    {{-- Tabs --}}
    <div class="gd-tabs">
        <button class="gd-tab active" onclick="gdriveTab(this,'pane-account')">Account</button>
        @if($serverUuid)
        <button class="gd-tab" onclick="gdriveTab(this,'pane-settings')">Settings</button>
        <button class="gd-tab" onclick="gdriveTab(this,'pane-logs')">Logs</button>
        @endif
    </div>

    {{-- Body --}}
    <div class="gd-body">

        {{-- Flash messages --}}
        @if(session('gdrive_success'))
        <div class="gd-flash gd-flash-success">✓ {{ session('gdrive_success') }}</div>
        @endif
        @if(session('gdrive_error'))
        <div class="gd-flash gd-flash-error">✗ {{ session('gdrive_error') }}</div>
        @endif

        {{-- ===== ACCOUNT TAB ===== --}}
        <div id="pane-account" class="gd-pane active">

            <div class="gd-card">
                <h3>Connection Status</h3>

                @if($connected)
                    <span class="gd-status connected">● Connected</span>
                    <p style="color:#94a3b8; font-size:.83rem; margin: 10px 0 14px;">
                        Signed in as <strong style="color:#e2e8f0;">{{ $token->google_email }}</strong>
                    </p>
                    <form method="POST" action="/extensions/{identifier}/oauth/disconnect">
                        @csrf
                        <button type="submit" class="gd-btn gd-btn-danger">
                            🔌 Disconnect Google Account
                        </button>
                    </form>
                @else
                    <span class="gd-status disconnected">● Not Connected</span>
                    <p style="color:#64748b; font-size:.83rem; margin: 10px 0 14px;">
                        Connect your Google account to enable automatic daily backups to your Google Drive.
                    </p>
                    @if($allowConnect === '1')
                        <a href="/extensions/{identifier}/oauth/connect{{ $serverUuid ? '?server='.$serverUuid : '' }}"
                           class="gd-btn gd-btn-google">
                            <svg width="16" height="16" viewBox="0 0 48 48" style="flex-shrink:0">
                                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                                <path fill="none" d="M0 0h48v48H0z"/>
                            </svg>
                            Sign in with Google
                        </a>
                    @else
                        <div class="gd-flash gd-flash-error">
                            ⚠ Google account connections are currently disabled by the administrator.
                        </div>
                    @endif
                @endif
            </div>

            <div class="gd-card">
                <h3>How It Works</h3>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    @foreach([
                        ['🔗', 'Connect your Google account using OAuth 2.0 — we never see your password.'],
                        ['⚙️', 'Enable automatic backups for each server individually in the Settings tab.'],
                        ['📦', 'Backups run daily at the scheduled hour configured by your administrator.'],
                        ['🗑️', 'Old backups are automatically deleted based on the retention policy.'],
                    ] as [$icon, $text])
                    <div style="display:flex; gap:10px; align-items:flex-start; font-size:.83rem; color:#94a3b8;">
                        <span style="flex-shrink:0; font-size:1rem;">{{ $icon }}</span>
                        <span>{{ $text }}</span>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        {{-- ===== SETTINGS TAB ===== --}}
        @if($serverUuid)
        <div id="pane-settings" class="gd-pane">

            @if(!$connected)
                <div class="gd-empty">
                    <span>🔗</span>
                    Connect your Google account first<br>to configure backup settings.
                </div>
            @else
                <form method="POST" action="/extensions/{identifier}/settings/{{ $serverUuid }}">
                    @csrf

                    <div class="gd-card">
                        <h3>Backup Schedule</h3>

                        <div class="gd-toggle-row">
                            <span class="gd-toggle-label">Enable automatic backups</span>
                            <label class="gd-switch">
                                <input type="checkbox" name="enabled" value="1"
                                    {{ ($backupSettings?->enabled ?? false) ? 'checked' : '' }}>
                                <span class="gd-slider"></span>
                            </label>
                        </div>

                        <div class="gd-form-group">
                            <label>Backup Frequency</label>
                            <select name="backup_frequency">
                                <option value="daily"  {{ ($backupSettings?->backup_frequency ?? 'daily') === 'daily'  ? 'selected' : '' }}>Daily</option>
                                <option value="weekly" {{ ($backupSettings?->backup_frequency ?? '') === 'weekly' ? 'selected' : '' }}>Weekly</option>
                            </select>
                        </div>

                        <div class="gd-form-group">
                            <label>Google Drive Folder Name</label>
                            <input type="text" name="folder_name"
                                   value="{{ $backupSettings?->folder_name ?? 'Pterodactyl Backups' }}"
                                   placeholder="Pterodactyl Backups">
                        </div>
                    </div>

                    <button type="submit" class="gd-btn gd-btn-primary">
                        💾 Save Settings
                    </button>
                </form>

                {{-- Manual backup trigger --}}
                <form method="POST" action="/extensions/{identifier}/backup/{{ $serverUuid }}/run" style="margin-top:10px;">
                    @csrf
                    <button type="submit" class="gd-btn gd-btn-secondary">
                        ▶ Run Manual Backup Now
                    </button>
                </form>
            @endif
        </div>

        {{-- ===== LOGS TAB ===== --}}
        <div id="pane-logs" class="gd-pane">

            @if(!$connected)
                <div class="gd-empty">
                    <span>🔗</span>
                    Connect your Google account<br>to view backup history.
                </div>
            @elseif($backupLogs->isEmpty())
                <div class="gd-empty">
                    <span>📂</span>
                    No backups yet.<br>Enable automatic backups in the Settings tab.
                </div>
            @else
                <div class="gd-card">
                    <h3>Recent Backups</h3>
                    @foreach($backupLogs as $log)
                    <div class="gd-log-item">
                        <span class="gd-log-icon">
                            @if($log->status === 'success') ✅
                            @elseif($log->status === 'failed') ❌
                            @else ⏳
                            @endif
                        </span>
                        <div class="gd-log-info">
                            <div class="gd-log-name">{{ $log->file_name ?? 'backup.tar.gz' }}</div>
                            <div class="gd-log-date">{{ \Carbon\Carbon::parse($log->created_at)->diffForHumans() }}</div>
                            @if($log->status === 'failed' && $log->error_message)
                                <div style="color:#f87171; font-size:.75rem; margin-top:2px;">{{ $log->error_message }}</div>
                            @endif
                        </div>
                        <span class="gd-log-size">
                            @if($log->file_size)
                                {{ round($log->file_size / 1048576, 1) }} MB
                            @endif
                        </span>
                    </div>
                    @endforeach
                </div>
            @endif
        </div>
        @endif

    </div>{{-- /gd-body --}}
</div>{{-- /gdrive-panel --}}

{{-- ============ Scripts ============ --}}
<script>
    function gdriveOpenPanel() {
        document.getElementById('gdrive-panel').classList.add('open');
        document.getElementById('gdrive-overlay').classList.add('visible');
        document.body.style.overflow = 'hidden';
    }
    function gdriveClosePanel() {
        document.getElementById('gdrive-panel').classList.remove('open');
        document.getElementById('gdrive-overlay').classList.remove('visible');
        document.body.style.overflow = '';
    }
    function gdriveTab(btn, paneId) {
        document.querySelectorAll('.gd-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.gd-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(paneId).classList.add('active');
    }
    // Open panel if there's a flash message from the OAuth flow
    @if(session('gdrive_success') || session('gdrive_error'))
    document.addEventListener('DOMContentLoaded', () => gdriveOpenPanel());
    @endif
</script>
