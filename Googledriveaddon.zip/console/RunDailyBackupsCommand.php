<?php
/**
 * Artisan command: googledrive:backup-daily
 *
 * Dispatches GoogleDriveBackupJob for every server that has backups enabled.
 * Scheduled by Console.yml to run daily.
 */

namespace Pterodactyl\Console\Commands\BlueprintFramework\Extensions\{identifier};

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Pterodactyl\BlueprintFramework\Extensions\{identifier}\Jobs\GoogleDriveBackupJob;

class RunDailyBackupsCommand extends Command
{
    protected $signature   = 'googledrive:backup-daily';
    protected $description = 'Dispatch Google Drive backup jobs for all servers with automatic backups enabled.';

    public function handle(): int
    {
        $settings = DB::table('gdrive_backup_settings')
            ->where('enabled', 1)
            ->get(['user_id', 'server_id', 'backup_frequency']);

        if ($settings->isEmpty()) {
            $this->info('[GoogleDriveBackups] No servers have backups enabled.');
            return self::SUCCESS;
        }

        $today      = now()->dayOfWeek; // 0 = Sunday
        $dispatched = 0;

        foreach ($settings as $row) {
            // Skip weekly backups unless it's Sunday
            if ($row->backup_frequency === 'weekly' && $today !== 0) {
                continue;
            }

            // Verify the user still has a connected token
            $hasToken = DB::table('gdrive_tokens')
                ->where('user_id', $row->user_id)
                ->whereNotNull('access_token')
                ->exists();

            if (!$hasToken) {
                $this->warn("[GoogleDriveBackups] User {$row->user_id} has no token — skipping server {$row->server_id}.");
                continue;
            }

            dispatch(new GoogleDriveBackupJob($row->server_id, $row->user_id));
            $dispatched++;

            $this->info("[GoogleDriveBackups] Queued backup for server {$row->server_id} (user {$row->user_id}).");
        }

        $this->info("[GoogleDriveBackups] Dispatched {$dispatched} backup job(s).");
        return self::SUCCESS;
    }
}
