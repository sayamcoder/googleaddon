<?php

namespace Pterodactyl\Http\Controllers\Admin\Extensions\{identifier};

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\BlueprintFramework\Libraries\ExtensionLibrary\Admin\BlueprintAdminLibrary as BlueprintExtensionLibrary;

class {identifier}ExtensionController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private BlueprintExtensionLibrary $blueprint,
    ) {}

    /**
     * Render the admin settings page (GET).
     */
    public function index(): View
    {
        $settings = [
            'client_id'        => $this->blueprint->dbGet('{identifier}', 'oauth_client_id') ?? '',
            'client_secret'    => $this->blueprint->dbGet('{identifier}', 'oauth_client_secret') ?? '',
            'retention_days'   => $this->blueprint->dbGet('{identifier}', 'retention_days') ?? 7,
            'backup_hour'      => $this->blueprint->dbGet('{identifier}', 'backup_hour') ?? 2,
            'allow_user_oauth' => $this->blueprint->dbGet('{identifier}', 'allow_user_oauth') ?? '1',
            'max_backups'      => $this->blueprint->dbGet('{identifier}', 'max_backups') ?? 5,
        ];

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'      => '/admin/extensions/{identifier}',
                'blueprint' => $this->blueprint,
                'settings'  => $settings,
            ]
        );
    }

    /**
     * Save admin settings (POST).
     */
    public function post(Request $request): RedirectResponse
    {
        $request->validate([
            'client_id'        => 'nullable|string|max:300',
            'client_secret'    => 'nullable|string|max:300',
            'retention_days'   => 'required|integer|min:1|max:365',
            'backup_hour'      => 'required|integer|min:0|max:23',
            'allow_user_oauth' => 'nullable|string|in:0,1',
            'max_backups'      => 'required|integer|min:1|max:50',
        ]);

        $this->blueprint->dbSet('{identifier}', 'oauth_client_id',     $request->input('client_id', ''));
        $this->blueprint->dbSet('{identifier}', 'oauth_client_secret', $request->input('client_secret', ''));
        $this->blueprint->dbSet('{identifier}', 'retention_days',      $request->input('retention_days', 7));
        $this->blueprint->dbSet('{identifier}', 'backup_hour',         $request->input('backup_hour', 2));
        $this->blueprint->dbSet('{identifier}', 'allow_user_oauth',    $request->input('allow_user_oauth', '0') ? '1' : '0');
        $this->blueprint->dbSet('{identifier}', 'max_backups',         $request->input('max_backups', 5));

        return redirect('/admin/extensions/{identifier}')->with('success', 'Settings saved successfully.');
    }
}
