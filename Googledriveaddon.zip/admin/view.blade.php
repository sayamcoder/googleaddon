@extends('layouts.admin')
@section('title', 'Extensions - Google Drive Backups')

@section('content-header')
<h1>Google Drive Backups <small>AutomaticGoogleDriveBackups Extension</small></h1>
<ol class="breadcrumb">
    <li><a href="{{ route('admin.index') }}">Admin</a></li>
    <li><a href="{{ route('admin.extensions.overview') }}">Extensions</a></li>
    <li class="active">Google Drive Backups</li>
</ol>
@endsection

@section('content')
<div style="max-width:1000px; margin:0 auto;">

    {{-- Header --}}
    <div class="gdrive-admin-header">
        <div>
            <h2>🟦 Google Drive Backups</h2>
            <p>Configure OAuth credentials and global backup policies. Users connect their own Google accounts from the server dashboard.</p>
        </div>
    </div>

    {{-- Flash messages --}}
    @if(session('success'))
    <div class="gdrive-alert gdrive-alert-success">
        <i class="fa fa-check-circle"></i> {{ session('success') }}
    </div>
    @endif

    @if(!$settings['client_id'] || !$settings['client_secret'])
    <div class="gdrive-alert gdrive-alert-warning">
        <i class="fa fa-exclamation-triangle"></i>
        <strong>Action required:</strong> Google OAuth credentials are not set. Users will not be able to connect their Google accounts until you add your Client ID and Client Secret below.
    </div>
    @endif

    {{-- Stats --}}
    <div class="gdrive-stats">
        @php
            $connectedUsers  = \DB::table('gdrive_tokens')->whereNotNull('access_token')->count();
            $totalBackupJobs = \DB::table('gdrive_backup_settings')->where('enabled', 1)->count();
            $totalBackups    = \DB::table('gdrive_backup_logs')->count();
            $failedBackups   = \DB::table('gdrive_backup_logs')->where('status', 'failed')->count();
        @endphp
        <div class="gdrive-stat-box">
            <div class="stat-value">{{ $connectedUsers }}</div>
            <div class="stat-label">Connected Users</div>
        </div>
        <div class="gdrive-stat-box">
            <div class="stat-value">{{ $totalBackupJobs }}</div>
            <div class="stat-label">Active Schedules</div>
        </div>
        <div class="gdrive-stat-box">
            <div class="stat-value">{{ $totalBackups }}</div>
            <div class="stat-label">Total Backups</div>
        </div>
        <div class="gdrive-stat-box">
            <div class="stat-value" style="{{ $failedBackups > 0 ? 'color:#f87171' : '' }}">{{ $failedBackups }}</div>
            <div class="stat-label">Failed Backups</div>
        </div>
    </div>

    <form method="POST" action="{{ $root }}">
        @csrf

        {{-- OAuth Credentials --}}
        <div class="gdrive-card">
            <h3><i class="fa fa-key"></i> Google OAuth 2.0 Credentials</h3>
            <p style="color:#64748b; font-size:0.85rem; margin-bottom:20px;">
                Create a project in the <a href="https://console.cloud.google.com/" target="_blank" style="color:#4285f4;">Google Cloud Console</a>,
                enable the <strong>Google Drive API</strong>, and create an OAuth 2.0 client ID (Web application type).
                Set the authorised redirect URI to: <code style="background:#131929;padding:2px 8px;border-radius:4px;font-size:0.8rem;">{{ url('/extensions/{identifier}/oauth/callback') }}</code>
            </p>
            <div class="gdrive-form-grid">
                <div class="gdrive-form-group">
                    <label>Client ID</label>
                    <input type="text" name="client_id" value="{{ old('client_id', $settings['client_id']) }}"
                           placeholder="1234567890-xxxx.apps.googleusercontent.com">
                    <span class="hint">From Google Cloud Console → Credentials</span>
                </div>
                <div class="gdrive-form-group">
                    <label>Client Secret</label>
                    <input type="password" name="client_secret" value="{{ old('client_secret', $settings['client_secret']) }}"
                           placeholder="GOCSPX-xxxxxxxxxxxxxxxx">
                    <span class="hint">Keep this secret. Never share it publicly.</span>
                </div>
            </div>
        </div>

        {{-- Global Backup Policy --}}
        <div class="gdrive-card">
            <h3><i class="fa fa-cog"></i> Global Backup Policy</h3>
            <div class="gdrive-form-grid">
                <div class="gdrive-form-group">
                    <label>Daily Backup Hour (UTC)</label>
                    <select name="backup_hour">
                        @for($h = 0; $h < 24; $h++)
                        <option value="{{ $h }}" {{ $settings['backup_hour'] == $h ? 'selected' : '' }}>
                            {{ str_pad($h, 2, '0', STR_PAD_LEFT) }}:00 UTC
                        </option>
                        @endfor
                    </select>
                    <span class="hint">What hour backups are triggered each day.</span>
                </div>
                <div class="gdrive-form-group">
                    <label>Retention Period (days)</label>
                    <input type="number" name="retention_days" value="{{ old('retention_days', $settings['retention_days']) }}"
                           min="1" max="365">
                    <span class="hint">Backups older than this are deleted from Drive.</span>
                </div>
                <div class="gdrive-form-group">
                    <label>Max Backups Per Server</label>
                    <input type="number" name="max_backups" value="{{ old('max_backups', $settings['max_backups']) }}"
                           min="1" max="50">
                    <span class="hint">Oldest backup is deleted when this limit is exceeded.</span>
                </div>
            </div>
        </div>

        {{-- Permissions --}}
        <div class="gdrive-card">
            <h3><i class="fa fa-users"></i> Permissions</h3>
            <div class="gdrive-toggle-row">
                <div class="gdrive-toggle-label">
                    <strong>Allow user Google account connections</strong>
                    <span>When disabled, no new users can connect their Google accounts.</span>
                </div>
                <label class="gdrive-switch">
                    <input type="checkbox" name="allow_user_oauth" value="1"
                        {{ $settings['allow_user_oauth'] == '1' ? 'checked' : '' }}>
                    <span class="gdrive-slider"></span>
                </label>
            </div>
        </div>

        <button type="submit" class="gdrive-btn gdrive-btn-primary">
            <i class="fa fa-save"></i> Save Settings
        </button>
    </form>

    {{-- Recent Backup Logs --}}
    <div class="gdrive-card" style="margin-top:28px;">
        <h3><i class="fa fa-history"></i> Recent Backup Activity</h3>
        @php
            $logs = \DB::table('gdrive_backup_logs')
                ->orderByDesc('created_at')
                ->limit(15)
                ->get();
        @endphp
        @if($logs->isEmpty())
            <p style="color:#64748b; text-align:center; padding:24px 0;">No backups have run yet.</p>
        @else
        <table style="width:100%; border-collapse:collapse; font-size:0.875rem; color:#e2e8f0;">
            <thead>
                <tr style="color:#64748b; border-bottom:1px solid #2d3450;">
                    <th style="text-align:left;padding:8px 0;">Server ID</th>
                    <th style="text-align:left;padding:8px 0;">User</th>
                    <th style="text-align:left;padding:8px 0;">Status</th>
                    <th style="text-align:left;padding:8px 0;">File</th>
                    <th style="text-align:left;padding:8px 0;">Date</th>
                </tr>
            </thead>
            <tbody>
                @foreach($logs as $log)
                <tr style="border-bottom:1px solid #1a2035;">
                    <td style="padding:8px 0; font-family:monospace; font-size:0.8rem;">{{ $log->server_id }}</td>
                    <td style="padding:8px 0;">{{ $log->user_email ?? '—' }}</td>
                    <td style="padding:8px 0;">
                        @if($log->status === 'success')
                            <span style="color:#34d399; font-weight:600;">✓ Success</span>
                        @elseif($log->status === 'failed')
                            <span style="color:#f87171; font-weight:600;">✗ Failed</span>
                        @else
                            <span style="color:#fbbf24;">⏳ Running</span>
                        @endif
                    </td>
                    <td style="padding:8px 0; font-size:0.8rem; color:#94a3b8;">{{ $log->file_name ?? '—' }}</td>
                    <td style="padding:8px 0; color:#64748b; font-size:0.8rem;">{{ $log->created_at }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @endif
    </div>

</div>
@endsection
