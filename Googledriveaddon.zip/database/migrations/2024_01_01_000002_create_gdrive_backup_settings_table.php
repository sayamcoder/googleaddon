<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('gdrive_backup_settings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->index();
            $table->char('server_id', 36)->index();
            $table->boolean('enabled')->default(false);
            $table->enum('backup_frequency', ['daily', 'weekly'])->default('daily');
            $table->string('folder_name', 150)->default('Pterodactyl Backups');
            $table->timestamps();

            $table->unique(['user_id', 'server_id']);
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('gdrive_backup_settings');
    }
};
