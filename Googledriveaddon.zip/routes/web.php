<?php
/**
 * Web routes for AutomaticGoogleDriveBackups extension.
 *
 * These routes are prefixed with /extensions/{identifier}/ by Blueprint.
 * Full URL examples:
 *   GET  /extensions/googledrive/oauth/connect
 *   GET  /extensions/googledrive/oauth/callback
 *   POST /extensions/googledrive/oauth/disconnect
 */

use Illuminate\Support\Facades\Route;
use Pterodactyl\BlueprintFramework\Extensions\{identifier}\GoogleDriveOAuthController;

Route::middleware(['web', 'auth'])->group(function () {

    // Redirect the user to Google's OAuth 2.0 consent screen
    Route::get('/oauth/connect', [GoogleDriveOAuthController::class, 'redirect'])
        ->name('{identifier}.oauth.connect');

    // Google redirects back here with an auth code
    Route::get('/oauth/callback', [GoogleDriveOAuthController::class, 'callback'])
        ->name('{identifier}.oauth.callback');

    // Disconnect / revoke the stored token
    Route::post('/oauth/disconnect', [GoogleDriveOAuthController::class, 'disconnect'])
        ->name('{identifier}.oauth.disconnect');

    // Per-server backup settings (posted from the dashboard wrapper)
    Route::post('/settings/{server}', [GoogleDriveOAuthController::class, 'saveSettings'])
        ->name('{identifier}.settings.save');

    // Trigger a manual backup for a server
    Route::post('/backup/{server}/run', [GoogleDriveOAuthController::class, 'triggerBackup'])
        ->name('{identifier}.backup.trigger');
});
