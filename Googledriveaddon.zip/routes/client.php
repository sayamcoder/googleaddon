<?php
/**
 * Client API routes for AutomaticGoogleDriveBackups extension.
 *
 * Prefixed with /api/client/extensions/{identifier}/ by Blueprint.
 * Requires a valid client API key in the Authorization header.
 */

use Illuminate\Support\Facades\Route;
use Pterodactyl\BlueprintFramework\Extensions\{identifier}\GoogleDriveClientApiController;

Route::middleware('auth:sanctum')->group(function () {

    // GET  /api/client/extensions/googledrive/status
    // Returns the current user's Google Drive connection status
    Route::get('/status', [GoogleDriveClientApiController::class, 'status']);

    // GET  /api/client/extensions/googledrive/servers/{server}/logs
    // Returns the backup logs for a specific server
    Route::get('/servers/{server}/logs', [GoogleDriveClientApiController::class, 'logs']);

    // GET  /api/client/extensions/googledrive/servers/{server}/settings
    // Returns the backup settings for a specific server
    Route::get('/servers/{server}/settings', [GoogleDriveClientApiController::class, 'getSettings']);
});
