<?php
/**
 * Daily Google Drive Backup Job
 *
 * Queued job that:
 *  1. Creates a Pterodactyl backup via the Wings API
 *  2. Downloads the backup archive
 *  3. Uploads it to the user's Google Drive
 *  4. Deletes old backups beyond the retention limit
 *  5. Logs the result to gdrive_backup_logs
 */

namespace Pterodactyl\BlueprintFramework\Extensions\{identifier}\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GoogleDriveBackupJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $timeout = 1800; // 30 minutes for large servers

    public function __construct(
        private string $serverUuid,
        private int    $userId
    ) {}

    public function handle(): void
    {
        $logId = DB::table('gdrive_backup_logs')->insertGetId([
            'user_id'    => $this->userId,
            'server_id'  => $this->serverUuid,
            'status'     => 'running',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        try {
            // 1. Get a fresh access token
            $accessToken = $this->getFreshAccessToken();
            if (!$accessToken) {
                throw new \Exception('Could not obtain a valid Google access token.');
            }

            // 2. Get user email for logging
            $userEmail = DB::table('gdrive_tokens')
                ->where('user_id', $this->userId)
                ->value('google_email');

            // 3. Resolve the Google Drive folder
            $folderName = DB::table('gdrive_backup_settings')
                ->where('user_id', $this->userId)
                ->where('server_id', $this->serverUuid)
                ->value('folder_name') ?? 'Pterodactyl Backups';

            $folderId = $this->getOrCreateDriveFolder($accessToken, $folderName);

            // 4. Create backup via Pterodactyl Application API
            $backupData = $this->createPterodactylBackup();
            $fileName   = $backupData['name'] ?? ('backup_' . now()->format('Y-m-d_H-i-s') . '.tar.gz');
            $downloadUrl = $backupData['url'] ?? null;

            if (!$downloadUrl) {
                throw new \Exception('Pterodactyl did not return a download URL for the backup.');
            }

            // 5. Upload to Google Drive
            $fileSize   = $backupData['bytes'] ?? 0;
            $driveFileId = $this->uploadToDrive($accessToken, $folderId, $fileName, $downloadUrl, $fileSize);

            // 6. Enforce max backup count
            $this->pruneOldBackups($accessToken, $folderId);

            // 7. Mark success
            DB::table('gdrive_backup_logs')->where('id', $logId)->update([
                'status'       => 'success',
                'file_name'    => $fileName,
                'file_size'    => $fileSize,
                'drive_file_id'=> $driveFileId,
                'user_email'   => $userEmail,
                'updated_at'   => now(),
            ]);

            Log::info("[GoogleDriveBackups] Backup successful for server {$this->serverUuid} (user {$this->userId}).");

        } catch (\Throwable $e) {
            DB::table('gdrive_backup_logs')->where('id', $logId)->update([
                'status'        => 'failed',
                'error_message' => $e->getMessage(),
                'updated_at'    => now(),
            ]);
            Log::error("[GoogleDriveBackups] Backup failed for {$this->serverUuid}: " . $e->getMessage());
            throw $e; // Re-throw so Laravel retries the job
        }
    }

    /**
     * Get a valid Google access token, refreshing if expired.
     */
    private function getFreshAccessToken(): ?string
    {
        $row = DB::table('gdrive_tokens')->where('user_id', $this->userId)->first();
        if (!$row) return null;

        // Token still valid with 5 min buffer
        if ($row->expires_at && now()->addMinutes(5)->lt($row->expires_at)) {
            return $row->access_token;
        }

        // Refresh
        if (!$row->refresh_token) return null;

        $clientId     = DB::table('blueprint_extension_settings')->where('extension', '{identifier}')->where('key', 'oauth_client_id')->value('value');
        $clientSecret = DB::table('blueprint_extension_settings')->where('extension', '{identifier}')->where('key', 'oauth_client_secret')->value('value');

        $resp = Http::asForm()->post('https://oauth2.googleapis.com/token', [
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
            'refresh_token' => $row->refresh_token,
            'grant_type'    => 'refresh_token',
        ]);

        if ($resp->failed()) return null;

        $tokens = $resp->json();

        DB::table('gdrive_tokens')->where('user_id', $this->userId)->update([
            'access_token' => $tokens['access_token'],
            'expires_at'   => now()->addSeconds($tokens['expires_in'] ?? 3600),
            'updated_at'   => now(),
        ]);

        return $tokens['access_token'];
    }

    /**
     * Find or create the backup folder in Google Drive.
     */
    private function getOrCreateDriveFolder(string $token, string $folderName): string
    {
        $query = "name='{$folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false";
        $resp  = Http::withToken($token)->get('https://www.googleapis.com/drive/v3/files', [
            'q'      => $query,
            'fields' => 'files(id,name)',
        ]);

        $files = $resp->json('files', []);
        if (!empty($files)) {
            return $files[0]['id'];
        }

        $create = Http::withToken($token)->post('https://www.googleapis.com/drive/v3/files', [
            'name'     => $folderName,
            'mimeType' => 'application/vnd.google-apps.folder',
        ]);

        return $create->json('id');
    }

    /**
     * Trigger a Pterodactyl backup and wait for it to complete.
     * Returns ['name', 'url', 'bytes'].
     */
    private function createPterodactylBackup(): array
    {
        $apiBase = rtrim(config('app.url'), '/');
        $apiKey  = config('pterodactyl.api_key', env('APP_SERVICE_KEY', ''));

        // Create backup
        $resp = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiKey,
            'Accept'        => 'application/json',
        ])->post("{$apiBase}/api/client/servers/{$this->serverUuid}/backups");

        if ($resp->failed()) {
            throw new \Exception('Failed to create Pterodactyl backup: ' . $resp->body());
        }

        $backup = $resp->json('attributes');
        $uuid   = $backup['uuid'];

        // Poll until backup is complete (max 25 min)
        $timeout = now()->addMinutes(25);
        while (now()->lt($timeout)) {
            sleep(15);
            $poll = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
                'Accept'        => 'application/json',
            ])->get("{$apiBase}/api/client/servers/{$this->serverUuid}/backups/{$uuid}");

            $attrs = $poll->json('attributes');
            if ($attrs['is_successful'] ?? false) {
                // Get download URL
                $dlResp = Http::withHeaders([
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Accept'        => 'application/json',
                ])->get("{$apiBase}/api/client/servers/{$this->serverUuid}/backups/{$uuid}/download");

                return [
                    'name'  => $attrs['name'] . '.tar.gz',
                    'url'   => $dlResp->json('attributes.url'),
                    'bytes' => $attrs['bytes'] ?? 0,
                ];
            }

            if (isset($attrs['completed_at']) && empty($attrs['is_successful'])) {
                throw new \Exception('Pterodactyl backup failed or was incomplete.');
            }
        }

        throw new \Exception('Timed out waiting for Pterodactyl backup to complete.');
    }

    /**
     * Upload the backup archive to Google Drive using resumable upload.
     */
    private function uploadToDrive(string $token, string $folderId, string $fileName, string $downloadUrl, int $fileSize): string
    {
        // Stream the backup directly to Drive via resumable upload
        $initResp = Http::withToken($token)
            ->withHeaders(['Content-Type' => 'application/json'])
            ->post(
                'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable',
                [
                    'name'    => $fileName,
                    'parents' => [$folderId],
                ]
            );

        if ($initResp->failed()) {
            throw new \Exception('Failed to initialise Drive resumable upload.');
        }

        $uploadUrl = $initResp->header('Location');

        // Download backup and pipe to Drive
        $backupStream = Http::withOptions(['stream' => true])->get($downloadUrl);
        $body         = $backupStream->toPsrResponse()->getBody();

        $uploadResp = Http::withToken($token)
            ->withHeaders([
                'Content-Type'   => 'application/octet-stream',
                'Content-Length' => $fileSize ?: '*',
            ])
            ->put($uploadUrl, (string) $body);

        if ($uploadResp->failed()) {
            throw new \Exception('Failed to upload backup to Google Drive.');
        }

        return $uploadResp->json('id');
    }

    /**
     * Delete the oldest backups if the max count is exceeded.
     */
    private function pruneOldBackups(string $token, string $folderId): void
    {
        $maxBackups = (int) (DB::table('blueprint_extension_settings')
            ->where('extension', '{identifier}')
            ->where('key', 'max_backups')
            ->value('value') ?? 5);

        $retentionDays = (int) (DB::table('blueprint_extension_settings')
            ->where('extension', '{identifier}')
            ->where('key', 'retention_days')
            ->value('value') ?? 7);

        $retentionDate = now()->subDays($retentionDays)->format('Y-m-d\TH:i:s\Z');

        // List files in the backup folder, oldest first
        $resp = Http::withToken($token)->get('https://www.googleapis.com/drive/v3/files', [
            'q'       => "'{$folderId}' in parents and trashed=false",
            'fields'  => 'files(id,name,createdTime)',
            'orderBy' => 'createdTime asc',
        ]);

        $files = $resp->json('files', []);

        foreach ($files as $file) {
            // Delete if beyond retention window
            if ($file['createdTime'] < $retentionDate) {
                Http::withToken($token)->delete("https://www.googleapis.com/drive/v3/files/{$file['id']}");
                continue;
            }
        }

        // Also enforce max count
        if (count($files) > $maxBackups) {
            $toDelete = array_slice($files, 0, count($files) - $maxBackups);
            foreach ($toDelete as $file) {
                Http::withToken($token)->delete("https://www.googleapis.com/drive/v3/files/{$file['id']}");
            }
        }
    }
}
