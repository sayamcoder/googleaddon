<?php
/**
 * Client API Controller
 *
 * Returns JSON responses for the client-facing API endpoints.
 */

namespace Pterodactyl\BlueprintFramework\Extensions\{identifier};

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Http\Controllers\Controller;

class GoogleDriveClientApiController extends Controller
{
    /**
     * Return the current user's Google Drive connection status.
     */
    public function status(Request $request): JsonResponse
    {
        $userId = Auth::id();
        $token  = DB::table('gdrive_tokens')->where('user_id', $userId)->first();

        return response()->json([
            'connected'    => !is_null($token),
            'google_email' => $token?->google_email,
            'expires_at'   => $token?->expires_at,
        ]);
    }

    /**
     * Return backup logs for a server.
     */
    public function logs(Request $request, string $server): JsonResponse
    {
        $userId = Auth::id();

        $logs = DB::table('gdrive_backup_logs')
            ->where('user_id', $userId)
            ->where('server_id', $server)
            ->orderByDesc('created_at')
            ->limit(20)
            ->get(['id', 'status', 'file_name', 'file_size', 'drive_file_id', 'error_message', 'created_at']);

        return response()->json(['data' => $logs]);
    }

    /**
     * Return backup settings for a server.
     */
    public function getSettings(Request $request, string $server): JsonResponse
    {
        $userId   = Auth::id();
        $settings = DB::table('gdrive_backup_settings')
            ->where('user_id', $userId)
            ->where('server_id', $server)
            ->first();

        return response()->json([
            'enabled'          => $settings?->enabled ?? false,
            'backup_frequency' => $settings?->backup_frequency ?? 'daily',
            'folder_name'      => $settings?->folder_name ?? 'Pterodactyl Backups',
        ]);
    }
}
