<?php
/**
 * Google Drive OAuth Controller
 *
 * Handles connecting/disconnecting Google accounts and saving per-server settings.
 * Placed in: app/BlueprintFramework/Extensions/{identifier}/
 *
 * Blueprint symlinks this directory from requests.app in conf.yml.
 */

namespace Pterodactyl\BlueprintFramework\Extensions\{identifier};

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Server;

class GoogleDriveOAuthController extends Controller
{
    private string $clientId;
    private string $clientSecret;
    private string $redirectUri;

    public function __construct()
    {
        $this->clientId     = DB::table('blueprint_extension_settings')
            ->where('extension', '{identifier}')
            ->where('key', 'oauth_client_id')
            ->value('value') ?? '';

        $this->clientSecret = DB::table('blueprint_extension_settings')
            ->where('extension', '{identifier}')
            ->where('key', 'oauth_client_secret')
            ->value('value') ?? '';

        $this->redirectUri  = url('/extensions/{identifier}/oauth/callback');
    }

    /**
     * Redirect to Google consent screen.
     */
    public function redirect(Request $request): RedirectResponse
    {
        if (!$this->clientId) {
            return back()->with('gdrive_error', 'Google OAuth is not configured by the administrator.');
        }

        $serverId = $request->query('server');

        $params = http_build_query([
            'client_id'     => $this->clientId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => 'code',
            'scope'         => 'https://www.googleapis.com/auth/drive.file openid email',
            'access_type'   => 'offline',
            'prompt'        => 'consent',
            'state'         => csrf_token() . '|' . ($serverId ?? ''),
        ]);

        return redirect('https://accounts.google.com/o/oauth2/v2/auth?' . $params);
    }

    /**
     * Handle Google OAuth callback.
     */
    public function callback(Request $request): RedirectResponse
    {
        $state  = $request->query('state', '');
        $parts  = explode('|', $state, 2);
        $code   = $request->query('code');

        if (!$code) {
            return redirect('/')->with('gdrive_error', 'Google authorization was denied or failed.');
        }

        // Exchange code for tokens
        $response = Http::asForm()->post('https://oauth2.googleapis.com/token', [
            'code'          => $code,
            'client_id'     => $this->clientId,
            'client_secret' => $this->clientSecret,
            'redirect_uri'  => $this->redirectUri,
            'grant_type'    => 'authorization_code',
        ]);

        if ($response->failed()) {
            return redirect('/')->with('gdrive_error', 'Failed to exchange authorization code with Google.');
        }

        $tokens = $response->json();

        // Get user info from Google
        $userInfo = Http::withToken($tokens['access_token'])
            ->get('https://www.googleapis.com/oauth2/v2/userinfo')
            ->json();

        $userId = Auth::id();

        DB::table('gdrive_tokens')->upsert([
            'user_id'       => $userId,
            'access_token'  => $tokens['access_token'],
            'refresh_token' => $tokens['refresh_token'] ?? null,
            'expires_at'    => now()->addSeconds($tokens['expires_in'] ?? 3600),
            'google_email'  => $userInfo['email'] ?? null,
            'updated_at'    => now(),
            'created_at'    => now(),
        ], ['user_id'], ['access_token', 'refresh_token', 'expires_at', 'google_email', 'updated_at']);

        return redirect('/')->with('gdrive_success', 'Google Drive connected successfully as ' . ($userInfo['email'] ?? 'unknown'));
    }

    /**
     * Revoke and delete the user's stored tokens.
     */
    public function disconnect(Request $request): RedirectResponse
    {
        $userId = Auth::id();
        $token  = DB::table('gdrive_tokens')->where('user_id', $userId)->value('access_token');

        if ($token) {
            Http::get('https://oauth2.googleapis.com/revoke', ['token' => $token]);
            DB::table('gdrive_tokens')->where('user_id', $userId)->delete();
        }

        return back()->with('gdrive_success', 'Google Drive disconnected successfully.');
    }

    /**
     * Save per-server backup settings.
     */
    public function saveSettings(Request $request, string $server): RedirectResponse
    {
        $request->validate([
            'enabled'          => 'nullable|boolean',
            'backup_frequency' => 'required|in:daily,weekly',
            'folder_name'      => 'nullable|string|max:100',
        ]);

        $userId = Auth::id();

        DB::table('gdrive_backup_settings')->upsert([
            'user_id'          => $userId,
            'server_id'        => $server,
            'enabled'          => $request->boolean('enabled') ? 1 : 0,
            'backup_frequency' => $request->input('backup_frequency', 'daily'),
            'folder_name'      => $request->input('folder_name', 'Pterodactyl Backups'),
            'updated_at'       => now(),
            'created_at'       => now(),
        ], ['user_id', 'server_id'], ['enabled', 'backup_frequency', 'folder_name', 'updated_at']);

        return back()->with('gdrive_success', 'Backup settings saved.');
    }

    /**
     * Trigger a manual backup (queues the job).
     */
    public function triggerBackup(Request $request, string $server): RedirectResponse
    {
        $userId = Auth::id();

        $token = DB::table('gdrive_tokens')->where('user_id', $userId)->first();

        if (!$token) {
            return back()->with('gdrive_error', 'Your Google account is not connected.');
        }

        // Dispatch backup job
        dispatch(new \Pterodactyl\BlueprintFramework\Extensions\{identifier}\Jobs\GoogleDriveBackupJob(
            $server,
            $userId
        ));

        return back()->with('gdrive_success', 'Backup queued successfully. It will run shortly.');
    }
}
