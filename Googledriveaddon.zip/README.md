# AutomaticGoogleDriveBackups

> A [Blueprint](https://blueprint.zip/) extension for [Pterodactyl Panel](https://pterodactyl.io/) that lets users connect their Google Drive account and automatically back up server files on a daily schedule.

---

## Features

- 🔗 **OAuth 2.0** — Users authenticate with their own Google account; no passwords stored
- 📦 **Automatic daily backups** — Runs at a configurable UTC hour every day
- 📅 **Weekly mode** — Per-server option to back up only once a week (Sundays)
- 🗑️ **Auto-pruning** — Deletes old backups beyond the retention window or max-count limit
- ▶ **Manual trigger** — Users can run an on-demand backup from the server dashboard
- 📊 **Backup logs** — Full history visible per server; admins see a global activity feed
- ⚙️ **Admin settings page** — Configure OAuth credentials and global backup policies

---

## Requirements

| Requirement | Version |
|---|---|
| Pterodactyl Panel | `1.x` |
| Blueprint Framework | `beta-2025-09` or later |
| PHP | `8.1+` |
| Laravel Queue worker | Required (for async backup jobs) |

---

## Installation

### 1 — Set up Google Cloud credentials

1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project (e.g. `pterodactyl-gdrive`).
3. Enable the **Google Drive API** for the project.
4. Go to **APIs & Services → Credentials → Create Credentials → OAuth 2.0 Client ID**.
5. Choose **Web application**.
6. Add an **Authorised redirect URI**:
   ```
   https://YOUR-PANEL-DOMAIN/extensions/googledrive/oauth/callback
   ```
7. Note down your **Client ID** and **Client Secret**.

---

### 2 — Install the extension

Upload `AutomaticGoogleDriveBackups.blueprint` to your Pterodactyl server and install it:

```bash
cd /var/www/pterodactyl
blueprint -i AutomaticGoogleDriveBackups
```

Blueprint will automatically:
- Run the database migrations (creates `gdrive_tokens`, `gdrive_backup_settings`, `gdrive_backup_logs`)
- Register the daily Artisan schedule
- Inject the dashboard wrapper and admin page

---

### 3 — Configure OAuth credentials

1. Log into your Pterodactyl admin panel.
2. Go to **Admin → Extensions → Google Drive Backups**.
3. Enter your **Client ID** and **Client Secret** from Step 1.
4. Configure the global backup policy (daily hour, retention days, max backups).
5. Click **Save Settings**.

---

### 4 — Ensure the queue worker is running

Backup jobs are dispatched to the Laravel queue. Make sure a worker is running:

```bash
# Check if supervisor is managing the worker
sudo supervisorctl status

# Or run manually (not for production)
cd /var/www/pterodactyl && php artisan queue:work --sleep=3 --tries=3
```

---

## User Guide

1. Open any server in the Pterodactyl dashboard.
2. Click the **🟦 blue floating button** (bottom-right) to open the Google Drive panel.
3. In the **Account** tab → click **Sign in with Google** and authorise the app.
4. Switch to the **Settings** tab → enable automatic backups, choose frequency and folder name.
5. Click **Save Settings**.
6. The **Logs** tab shows backup history and status for that server.

---

## Directory Structure

```
AutomaticGoogleDriveBackups/
├── conf.yml                          # Blueprint extension config
├── assets/
│   └── icon.png                      # Extension icon
├── admin/
│   ├── view.blade.php                 # Admin settings page
│   ├── controller.php                 # Admin controller (GET/POST)
│   └── admin.css                      # Admin panel styles
├── dashboard/
│   ├── wrapper.blade.php              # Sliding panel injected into server pages
│   └── dashboard.css                  # Dashboard CSS (bundled into React)
├── routes/
│   ├── web.php                        # OAuth flow + settings routes
│   └── client.php                     # Client API routes (JSON)
├── app/
│   ├── GoogleDriveOAuthController.php # OAuth connect/disconnect/settings
│   ├── GoogleDriveClientApiController.php # Client API endpoints
│   └── Jobs/
│       └── GoogleDriveBackupJob.php   # Queued backup job
├── console/
│   ├── Console.yml                    # Scheduler config
│   └── RunDailyBackupsCommand.php     # php artisan googledrive:backup-daily
└── database/
    └── migrations/
        ├── ..._create_gdrive_tokens_table.php
        ├── ..._create_gdrive_backup_settings_table.php
        └── ..._create_gdrive_backup_logs_table.php
```

---

## API Endpoints

All client endpoints require a valid Pterodactyl client API key.

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/client/extensions/googledrive/status` | Connection status for the current user |
| `GET` | `/api/client/extensions/googledrive/servers/{uuid}/logs` | Backup logs for a server |
| `GET` | `/api/client/extensions/googledrive/servers/{uuid}/settings` | Backup settings for a server |
| `GET` | `/extensions/googledrive/oauth/connect` | Start Google OAuth flow |
| `GET` | `/extensions/googledrive/oauth/callback` | OAuth callback (handled automatically) |
| `POST` | `/extensions/googledrive/oauth/disconnect` | Revoke & remove Google token |
| `POST` | `/extensions/googledrive/settings/{server}` | Save per-server backup settings |
| `POST` | `/extensions/googledrive/backup/{server}/run` | Trigger a manual backup |

---

## Database Tables

| Table | Purpose |
|---|---|
| `gdrive_tokens` | Stores OAuth access/refresh tokens per user |
| `gdrive_backup_settings` | Per-server backup configuration (enabled, frequency, folder) |
| `gdrive_backup_logs` | Audit log of every backup run (status, file name, size, errors) |
| `blueprint_extension_settings` | Global admin settings (managed by Blueprint) |

---

## Uninstall

```bash
cd /var/www/pterodactyl
blueprint -r googledrive
```

This removes the extension files. To also drop the database tables:

```bash
php artisan db:table gdrive_backup_logs --drop
php artisan db:table gdrive_backup_settings --drop
php artisan db:table gdrive_tokens --drop
```

---

## License

MIT License — feel free to modify and redistribute.
